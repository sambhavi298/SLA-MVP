from flask import Blueprint, request, jsonify
from app.models.debug_model import insert_debug_log, get_debug_logs

debug_bp = Blueprint('debug', __name__)

@debug_bp.route('/', methods=['POST'])
def create_debug_log():
    data = request.get_json()
    if not data or 'code' not in data:
        return jsonify({"error": "Code data is required"}), 400
    
    log = {
        "code": data['code'],
        "result": data.get('result', ''),
        "timestamp": data.get('timestamp', '')
    }
    inserted_id = insert_debug_log(log)
    return jsonify({"message": "Debug log created", "id": str(inserted_id)}), 201

@debug_bp.route('/', methods=['GET'])
def fetch_debug_logs():
    logs = get_debug_logs()
    return jsonify({"debug_logs": logs}), 200
