from flask import Flask
from flask_pymongo import PyMongo
from flask_cors import CORS
from dotenv import load_dotenv
import os
from pymongo import MongoClient


mongo = PyMongo()

def create_app():
    app = Flask(__name__)
    load_dotenv()

    # Load config from .env
    app.config['DB'] = MongoClient('mongodb+srv://sla_user:sla@123@sla-cluster.euxya.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')['sla_db']
    
   # mongo.init_app(app)
    CORS(app)

    # ✅ Corrected Blueprint Imports:
    from app.routes.health_routes import health_bp
    from app.routes.debug_routes import debug_bp
    from app.routes.optimize_routes import optimize_bp

    # Register Blueprints
    app.register_blueprint(health_bp)
    app.register_blueprint(debug_bp)
    app.register_blueprint(optimize_bp)

    return app
